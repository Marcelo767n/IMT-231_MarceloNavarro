#ifndef FUNCIONES_H
#define FUNCIONES_H

int par_impar(int a);
int cont_digitos(int a);
void SemaforoColores();
void acumular_positivos();
void sumar();
void restar();
void multiplicar();
void compararNumeros(int a, int b);
int esMultiploDe3(int num);
int factorial(int n);
int invertirNumero(int num);

#endif

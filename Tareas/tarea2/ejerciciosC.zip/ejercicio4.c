#include <stdio.h>
#include "funciones.h"
//acumulador de valores positivos 
int main(){
    acumular_positivos();
    return 0;
}

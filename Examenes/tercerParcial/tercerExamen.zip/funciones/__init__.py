from .divisores import sumaDivisores
from .trianguloLetras import trianguloCaracteres
from .numerosPrimos import mostrarPrimerosPrimos
from .fibonacci import fibonacciInversa

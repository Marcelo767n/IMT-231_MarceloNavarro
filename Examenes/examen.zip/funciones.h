#ifndef FUNCIONES_H
#define FUNCIONES_H

int Esprimo(int n);
void factorial();
void ContarParesImpares();
void Multiplosde3();


#endif
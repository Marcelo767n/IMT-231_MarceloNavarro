def dividir(a,b):
    if b==0:
        print("Error: Division por cero no es permitida")
        return None
    resultado= a / b
    print(f"resultado de la division: {resultado}")
    return resultado
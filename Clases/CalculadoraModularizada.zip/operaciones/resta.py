def restar(a, b):
    resultado= a - b
    print(f"resultado de la resta: {resultado}")
    return resultado
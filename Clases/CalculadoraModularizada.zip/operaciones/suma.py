
def sumar(n1, n2):
    resultado = n1 + n2
    return resultado

def multiplicar(a, b):
    Resultado= a * b
    print(f"resultado de la multiplicacion: {Resultado}")
    return Resultado